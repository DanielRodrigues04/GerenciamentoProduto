﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciamentoProduto
{
    class Produto
    {
        string codigo;
        string nome;
        double peso;
        double precoCompra;
        double precoVenda;
        int quantidade;

        readonly static string caminhoArquivo = Path.Combine(Directory.GetCurrentDirectory(), "banco_de_dados.txt");

        public Produto(string codigo, string nome, double peso, double precoCompra, double precoVenda, int quantidade)
        {
            this.Codigo = codigo;
            this.Nome = nome;
            this.Peso = peso;
            this.PrecoCompra = precoCompra;
            this.PrecoVenda = precoVenda;
            this.Quantidade = quantidade;
        }

        public static Produto montarProduto(string linhaBanco)
        {
            var campos = linhaBanco.Split(';');
            var codigo = campos[0];
            var nome = campos[1];
            var precoCompra = Double.Parse(campos[2]);
            var precoVenda = Double.Parse(campos[3]);
            var peso = Double.Parse(campos[4]);
            var quantidade = int.Parse(campos[5]);

            return new Produto(
               codigo,
               nome,
               peso,
               precoCompra,
               precoVenda,
               quantidade);
        }

        public static List<Produto> carregarProdutos()
        {   
            List<Produto> produtos = new List<Produto>();

            var linhas = File.ReadAllLines(caminhoArquivo).ToList();
            
            linhas.RemoveAt(0);

            linhas.ForEach(linha => {             
                var produto = montarProduto(linha);

                produtos.Add(produto);
            });

            return produtos;
        }

        public string Codigo { get => codigo; set => codigo = value; }
        public string Nome { get => nome; set => nome = value; }
        public double Peso { get => peso; set => peso = value; }
        public double PrecoCompra { get => precoCompra; set => precoCompra = value; }
        public double PrecoVenda { get => precoVenda; set => precoVenda = value; }
        public int Quantidade { get => quantidade; set => quantidade = value; }
    }
}
