# GerenciamentoProduto-4-Periodo-P.I
Alunos: Daniel Filipe Tavares Rodrigues RA:2022101144 , Lynconl Felipe Assunção RA:2018101836
